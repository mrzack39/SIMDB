<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
*/
function fetchRecord()
{
    $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
        if(count($_POST) > 0) 
        {
            $arr = array();
            $opr = strtolower(substr($_POST["operator"], 0 , 1));
            $tables_query = mysqli_query($conn,"SELECT table_name FROM information_schema.tables WHERE table_schema = 'zohafab_bb' AND table_name LIKE '$opr%' ORDER BY table_name asc;");
            if(mysqli_num_rows($tables_query) > 0)
            {
                while($row0 = mysqli_fetch_assoc($tables_query) )
                {
                    $table_name =  $row0["table_name"];
                    $number= trim($_POST["number"] , " " );
                    if( strlen($number) == 10)
                    {
                        $result = mysqli_query($conn,"SELECT * FROM `$table_name` where `Mobile` = '$number' ");
                        if(mysqli_num_rows($result) > 0 )
                        {
                            while($row = mysqli_fetch_assoc($result)) 
                            {
                                array_push($row, ucfirst($_POST["operator"]) );
                                array_push($arr , $row);
                                unset($row);
                            }
                            break;
                        }
                    }else if(strlen($number) == 13)
                    {
                        $result = mysqli_query($conn,"SELECT * FROM `$table_name` where `Cnic` = '$number' ");
                        if(mysqli_num_rows($result) > 0 )
                        {
                            while($row = mysqli_fetch_assoc($result))
                            {
                                array_push($row, ucfirst($_POST["operator"]) );
                                array_push($arr , $row);
                                unset($row);
                            }
                            continue;
                        }
                    }else{ break;}
                    
                }
            }
            if( (getTotalCoins() == 0) && (checkSpecialAccess() == false) )
            {
                return '
                <tr><td class="bg-danger text-white" colspan=2>Coins limit exceeded</td></tr>';
            }
            else if( (checkSpecialAccess() == true) || (getTotalCoins() > 0) )
            {
                $output = '';
                if(count($arr) > 0)
                {
                    for($i = 0;$i < count($arr);$i++)
                    {
                        $output .= '
                        <tr style="background-color:gold;font-weight:bold;">
                        <td><i>Mobile No</i></td>
                        <td>'.$arr[$i]["Mobile"].'</td>
                    </tr>
                    <tr>
                        <td><i>Name</i></td>
                        <td>'.$arr[$i]["Name"].'</td>
                    </tr>
                    <tr>
                        <td><i>CNIC</i></td>
                        <td>'.$arr[$i]["CNIC"].'</td>
                    </tr>
                    <tr>
                        <td><i>Address</i></td>
                        <td>'.$arr[$i]["Address"].'</td>
                    </tr>';        
                    }
                    return $output;
                }
            }
        }
}


function fetchRecordUsingLink($number)
{
    // Validate and handle coin limits
    if (strlen($number) == 13 && getTotalCoins() < 50) {
        return '<tr><td class="bg-danger text-white" colspan="5">Coins limit exceeded</td></tr>';
    } else if (getTotalCoins() < 40) {
        return '<tr><td class="bg-danger text-white" colspan="5">Coins limit exceeded</td></tr>';
    }

    // Construct API URL
    $url = "https://kingfinders.click/api/Asim.php?number=" . $number;

    // Set up data for logging
    $folderPath = 'User_Search_Logs';
    if (!file_exists($folderPath)) {
        mkdir($folderPath, 0777, true);
    }

    $filename = $folderPath . '/' . date('d-m-Y') . '.json';
    $data['timestamp'] = date('Y-m-d H:i:s');

    // Encode the data to JSON format
    $jsonData = json_encode($data, JSON_PRETTY_PRINT);

    // Append the JSON data to the file
    file_put_contents($filename, $jsonData, FILE_APPEND);

    // Initialize cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL session
    $response = curl_exec($ch);
    $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Check for errors
    if ($response === false) {
        return "Request failed: " . curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);

    // Decode JSON response
    $arrayData = json_decode($response, true);

    // Process API response
    if (isset($arrayData['data']) && is_array($arrayData['data'])) {
        // Initialize output
        $output = '<div class="container mt-4">
            <h2>Result</h2>
            <div class="table-responsive" style="width:800px !important;">
                <table class="table table-bordered table-hover thead-dark">
                    <thead>
                        <tr style="border:none;background: white;">
                            <th colspan="7" style="text-align: center;"> <img src="images/upaisa-logo.png" style="height: 86px;width: 144px;"> </th>
                        </tr>
                        <tr>
                            <th>Upaisa Number</th>
                            <th>Upaisa User Name</th>
                            <th>Upaisa Account Cnic</th>
                            <th>Upaisa user address</th>
                            <th>Status</th>
                            <th>Brand</th>
                            <th>Network</th>
                        </tr>
                    </thead>
                    <tbody>';

        // Iterate through data records
        foreach ($arrayData['data'] as $record) {
            // Extract relevant fields
            $mobile = isset($record['mobile']) ? $record['mobile'] : '';
            $name = isset($record['name']) ? $record['name'] : '';
            $cnic = isset($record['cnic']) ? $record['cnic'] : '';
            $address = isset($record['address']) ? $record['address'] : '';

            // Check if mobile number belongs to Jazz network
            $firstThree = substr($mobile, 0, 3);
            $cus_style = '';
            $image = '';

            if (in_array($firstThree, array('300', '301', '302', '303', '304', '305', '306', '307', '308', '309', '324', '325', '326', '327', '328', '330', '331', '332', '333', '334', '335', '336', '337', '338', '339'))) {
                // Jazz numbers styling and image
                $cus_style = 'style="background:#d71a20;color:white;"';
                $image = '<img src="images/easypaisa-logo.png" style="height: 25px;width: 25px;">';
            }

            // Append row to output
            $output .= '
                        <tr>
                            <td>' . $mobile . '</td>
                            <td>' . $name . '</td>
                            <td>' . $cnic . '</td>
                            <td>' . $address . '</td>
                            <td> Active </td>
                            <td> ' . $image . ' </td>
                            <td> Easypaisa </td>
                        </tr>';
        }

        // Close table and container
        $output .= '</tbody></table></div></div>';

        // Return generated output
        return $output;
    } else {
        // Handle case where no data is available
        return 'No data available';
    }
}

function getCoinsExpiry()
{
    $conn = mysqli_connect("localhost", "simdcfob_aa", "simdcfob_aa", "simdcfob_aa");
    
    $id = isset($_SESSION["id"]) ? $_SESSION["id"] : NULL;
    
    if ($id != NULL)
    {
        $result = mysqli_query($conn, "SELECT * FROM `transaction_history` WHERE `to_user` = '$id' ORDER BY `sent_time` DESC LIMIT 1");
        
        if (mysqli_num_rows($result) > 0)
        {
            while ($row = mysqli_fetch_assoc($result)) 
            {
                $coinsexpiry = $row["sent_time"];
                return $coinsexpiry;
            }
        }
    }
    
    // Return "Buy Now" if there are no results or $id is NULL
    return '<a href="https://wa.me/+923207483733" style="text-decoration:none;color:white;cursor:pointer" target="_blank">Buy Now</a>';
}


function getTotalCoins()
{
    $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $result = mysqli_query($conn,"SELECT * FROM `users` where `id` = '$id' LIMIT 1 ");
        if(mysqli_num_rows($result) > 0 )
        {
            while($row = mysqli_fetch_assoc($result)) 
            {
                $coins = (int) $row["coins"];
                return $coins;
            }
        }
    }
}


function checkSpecialAccess()
{
    $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $result = mysqli_query($conn,"SELECT * FROM `users` where `id` = '$id' LIMIT 1 ");
        if(mysqli_num_rows($result) > 0 )
        {
            while($row = mysqli_fetch_assoc($result)) 
            {
                if( strval($row["special_access"]) == "1")
                {
                    return true;
                }else { return false; } 
            }
        }
    }
}

 

function deleteMyCoins($quantity)
{
    
    $conn = mysqli_connect("localhost", "simdcfob_aa", "simdcfob_aa", "simdcfob_aa");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"] : NULL;

    if ($id !== NULL) {
        $result = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1 ");

        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $coins = (int) $row["coins"];

                if ($coins >= $quantity) {
                    $coins -= $quantity;
                    
                    $result1 = mysqli_query($conn, "UPDATE `users` SET coins = '$coins' WHERE `id` ='$id' ");

                    // Check if the update query was successful
                    if ($result1) {
                        // Check how many rows were affected by the update
                        if (mysqli_affected_rows($conn) > 0) {
                            return true;
                        } else {
                            // Handle the case where the update did not affect any rows
                            return false;
                        }
                    } else {
                        // Handle the case where the update query fails
                        return false;
                    }
                } else {
                    // Handle the case where there are not enough coins
                    return false;
                }
            } else {
                // Handle the case where no rows were returned
                return false;
            }
        } else {
            // Handle the case where the query fails
            return false;
        }
    } else {
        // Handle the case where $id is NULL
        return false;
    }

    // Close the database connection
    mysqli_close($conn);
}


function shareCoins($username, $quantity)
{
    if (checkSpecialAccess() == true) {
        return '<div class="alert alert-danger">You cannot share coins because you have special Account</div>';
    } else {
        $conn = mysqli_connect("localhost", "simdcfob_aa", "simdcfob_aa", "simdcfob_aa");

        // Check if the connection was successful
        if (!$conn) {
            return '<div class="alert alert-danger">Database connection error: ' . mysqli_connect_error() . '</div>';
        }
  
        if (getTotalCoins() >= ($quantity + 1)) {
            $result = mysqli_query($conn, "SELECT * FROM `users` WHERE `username` = '$username' LIMIT 1 ");

            // Check if the query was successful
            if ($result) {
                // Check if any rows were returned
                if (mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_assoc($result);
                    $user_id = $row["id"];
                    $coins = (int) $row["coins"];
                    $coins = $coins + $quantity + 1;

                    $result1 = mysqli_query($conn, "UPDATE `users` SET `coins` = '$coins' WHERE `username`='$username' ");

                    // Check if the update query was successful
                    if ($result1) {
                        deleteMyCoins($quantity + 1);
                        insertTransaction($user_id, $quantity + 1);
                        return '<div class="alert alert-success">Coins Transferred Successfully</div>';
                    } else {
                        // Handle the case where the update query fails
                        return '<div class="alert alert-danger">System Error. Unable to share Coins</div>';
                    }
                } else {
                    // Handle the case where no rows were returned
                    return '<div class="alert alert-danger">Username Does not exist</div>';
                }
            } else {
                // Handle the case where the query fails
                return '<div class="alert alert-danger">Error fetching user data: ' . mysqli_error($conn) . '</div>';
            }
        } else {
            return '<div class="alert alert-danger">Your Account Does not have required Coins to Share.</div>';
        }

        // Close the database connection
        mysqli_close($conn);
    }
}

function fetchKarachiVehicleRecord()
{
    $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
        if(count($_POST) > 0) 
        {
            $arr = array();
            $tbr = array();
            $number = trim($_POST["number"] , ' ');
            $query = mysqli_query($conn,"SELECT * FROM `2wr_1950_2017` WHERE `regno`='$number' OR `cnic`='$number' ");
            if(mysqli_num_rows($query) > 0)
            {
                while($row = mysqli_fetch_array($query,MYSQLI_NUM))
                {
                    array_push($arr,$row);
                    unset($row);
                }
                  $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='punjabfata_bb' AND `TABLE_NAME`='2wr_1950_2017';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
            }else
            {
                $query1 = mysqli_query($conn,"SELECT * FROM `4w_1950_2017` WHERE `regno`='$number' OR `cnic`='$number' ");
                if(mysqli_num_rows($query1) > 0)
                {
                    while($row = mysqli_fetch_array($query1,MYSQLI_NUM))
                    {
                        array_push($arr,$row);
                        unset($row);
                    }
                      $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='punjabfata_bb' AND `TABLE_NAME`='4w_1950_2017';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
                }
            }
            
           if( (getTotalCoins() == 0) && (checkSpecialAccess() == false) )
            {
                return '
                <tr><td class="bg-danger text-white" colspan=2>Coins limit exceeded</td></tr>';
            }
            else if( (checkSpecialAccess() == true) || (getTotalCoins() > 0) )
            {
                $output = '';
                if(count($arr) > 0)
                {
                
                    for($i = 0;$i < count($arr[0]);$i++)
                    {
                        if( strtolower($tbr[0][$i]) == "id" )
                        {
                            continue;
                        }
                        $output .= $tbr[0][$i];
                        if( trim(strtolower($tbr[$i][0]) , ' ') == "regno")
                        {
                             $output .= '
                                <tr  class="bg-primary text-white" style="font-weight:bold;">
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';   
                        }else
                        {
                            $output .= '
                                <tr>
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';
                        }
                    }
                    
                    
                    return $output;
                }
            }
        }
}

function fetchPunjabVehicleRecord()
{
    $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
        if(count($_POST) > 0) 
        {
            $arr = array();
            $tbr = array();
            $number = trim($_POST["number"] , ' ');
            $query = mysqli_query($conn,"SELECT * FROM `Sheet 1` WHERE `VEH_REG_NO`='$number' OR `cnic`='$number' ");
            if(mysqli_num_rows($query) > 0)
            {
                while($row = mysqli_fetch_array($query,MYSQLI_NUM))
                {
                    array_push($arr,$row);
                    unset($row);
                }
                  $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='ptracker_bb' AND `TABLE_NAME`='Sheet 1';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
            }else
            {
                $query1 = mysqli_query($conn,"SELECT * FROM `Sheet 47` WHERE `VEH_REG_NO`='$number' OR `cnic`='$number' ");
                if(mysqli_num_rows($query1) > 0)
                {
                    while($row = mysqli_fetch_array($query1,MYSQLI_NUM))
                    {
                        array_push($arr,$row);
                        unset($row);
                    }
                      $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='ptracker_bb' AND `TABLE_NAME`='Sheet 47';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
                }
            }
            
           if( (getTotalCoins() == 0) && (checkSpecialAccess() == false) )
            {
                return '
                <tr><td class="bg-danger text-white" colspan=2>Coins limit exceeded</td></tr>';
            }
            else if( (checkSpecialAccess() == true) || (getTotalCoins() > 0) )
            {
                $output = '';
                if(count($arr) > 0)
                {
                
                    for($i = 0;$i < count($arr[0]);$i++)
                    {
                        if( strtolower($tbr[0][$i]) == "id" )
                        {
                            continue;
                        }
                        $output .= $tbr[0][$i];
                        if( trim(strtolower($tbr[$i][0]) , ' ') == "regno")
                        {
                             $output .= '
                                <tr  class="bg-primary text-white" style="font-weight:bold;">
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';   
                        }else
                        {
                            $output .= '
                                <tr>
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';
                        }
                    }
                    
                    
                    return $output;
                }
            }
        }
}

function insertTransaction($to_user, $coins)
{
    $conn = mysqli_connect("localhost", "simdcfob_aa", "simdcfob_aa", "simdcfob_aa");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"] : NULL;

    if ($id !== NULL) {
        $result = mysqli_query($conn, "INSERT INTO `transaction_history` (`from_user`, `to_user`, `coins`) VALUES ('$id', '$to_user', '$coins') ");

        // Check if the insert query was successful
        if ($result) {
            return true;
        } else {
            // Handle the case where the insert query fails
            return false;
        }
    } else {
        // Handle the case where $id is NULL
        return false;
    }

    // Close the database connection
    mysqli_close($conn);
}


/*function insertTransaction($to_user,$coins)
{
      $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $result = mysqli_query($conn,"INSERT INTO `transaction_history` (`from_user`,`to_user`,`coins`) VALUES ('$id','$to_user','$coins') ");
        if(mysqli_num_rows($result) > 0 )
        {
            return true;
        }else { return false; }
    }
}*/


function getUsername($userid)
{
     $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
$result = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '$userid' ");
     
    if(mysqli_num_rows($result) > 0 )
    {
        while($row =  mysqli_fetch_assoc($result))
        {
            $name =  htmlentities($row["username"]);
        }
        $conn->close();
        return $name;
    }else
    {
        return "";
    }
    
    
}

function showTransactions()
{
    $output = '';
       $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
     $username = isset($_SESSION["username"]) ? $_SESSION["username"]: NULL;
    if( $id != NULL)
    {
        $result = mysqli_query($conn,"SELECT * FROM `transaction_history` WHERE `from_user` = '$id' OR `to_user` = '$id' AND DATE(sent_time) >= DATE(NOW()) - INTERVAL 30 DAY ");
        
        if(mysqli_num_rows($result) > 0 )
        {
            while($row = mysqli_fetch_assoc($result))
            {
                if($row["from_user"] == $id)
                {
                    $method = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="red" class="bi bi-arrow-up" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M8 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L7.5 2.707V14.5a.5.5 0 0 0 .5.5z"/>
                    </svg> Sent';
                }else
                {
                    $method = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green" class="bi bi-arrow-down" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z"/>
                    </svg> Received';
                }
                
                $from_user = getUsername( $row["from_user"] );
                $to_user = getUsername( $row["to_user"] );
                
                $time = date("H:m, d M",strtotime($row["sent_time"]));
                $output .= '<tr>
                  <td>'.$from_user.'</td>
                  <td>'.$to_user.'</td>
                  <td>'.$row["coins"].'</td>
                  <td>'.$time.'</td>
                  <td>'.$method.'</td>
                </tr>';
            }
            return $output;
        }else { return false; }
    }
    $conn->close();
}


?>