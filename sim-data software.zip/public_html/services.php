<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}


 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Search For Info</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
  <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script> 
  
<style>
 

#pageloader
{
  background: rgba( 255, 255, 255, 0.8 );
  height: 100%;
  display:none;
  position: relative;
  width: 100%;
  z-index: 9999;
}

#pageloader img
{
  position: absolute;
  margin-left: 35%;
  margin-top: 30%;
  width:auto;
  max-height:100px;
}
body{
    overflow-x: hidden;
}

@media screen and (max-width: 576px) {
#pageloader img
{
  position: absolute;
  margin-left: 10%;
  margin-top: 70%;
  width:auto;
  max-height:100px;
}


 
}
.text-muted {
    color: #070cfc !important;
    font-size: large;
    font-weight: bolder;
    background: #ffffff;
    padding: 5px;
    border-radius: 8px;
}
  
 .card{cursor: pointer}.hd{font-size: 25px;font-weight: 550}.card.hover, .card:hover{box-shadow: 0 20px 40px rgba(0, 0, 0, .2)}.img{margin-bottom: 35px;-webkit-filter: drop-shadow(5px 5px 5px #222);filter: drop-shadow(5px 5px 5px #222)}.card-title{font-weight: 600}button.focus, button:focus{outline: 0;box-shadow: none !important}.ft{margin-top: 25px}.chk{margin-bottom: 5px}.rck{margin-top: 20px;padding-bottom: 15px}
 
 .hd {
    font-size: 29px;
    font-weight: 550;
    font-family: fantasy;
}
<style>
    .card-content {
        overflow: hidden;
        position: relative;
    }

    .card-content img {
        transition: transform 0.5s ease;
    }

    .zoom-in {
        transform: scale(1.1);
    }
</style>

<script>
    // Add an event listener for the scroll event
    window.addEventListener('scroll', function() {
        // Get the position of the top of the viewport
        var topOfWindow = window.pageYOffset || document.documentElement.scrollTop;

        // Get all elements with the class 'card-content'
        var cardContents = document.querySelectorAll('.card-content');

        // Loop through each 'card-content' element
        cardContents.forEach(function(cardContent) {
            // Get the position of the top of the 'card-content' element relative to the viewport
            var topOfCard = cardContent.getBoundingClientRect().top;

            // Check if the top of the 'card-content' element is within the viewport
            if (topOfCard < window.innerHeight && topOfCard > 0) {
                // Add the 'zoom-in' class to the 'img' element inside the 'card-content'
                cardContent.querySelector('img').classList.add('zoom-in');
            } else {
                // Remove the 'zoom-in' class if the 'card-content' element is not within the viewport
                cardContent.querySelector('img').classList.remove('zoom-in');
            }
        });
    });
</script>

</style>
</head>

<body>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-12">
                <div id="pageloader">
                    <img src= "form_loader.gif"/>
                </div>
            </div>
        </div>
    </div>
 
 <?php include('header.php'); ?>
 
 
 <div class='container-fluid mx-auto mt-5 mb-5 col-12' style="text-align: center">
     <a href="/" class="btn btn-primary">Home</a>
    <div class="hd">Our Services</div>
    <p> </p>
    <div class="row" style="justify-content: center">
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/vaccine.jpg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>All Vaccination Price 3000 Pkr</b></small> </p>
                        <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/cnic-service.jpeg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>Cnic Color Copy Price 2000 Pkr</b></small> </p>
                       <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/vehicle-service.jpeg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted">All Vehicle Data price 3000 pkr</small> </p>
                        <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/7c6800f9-d044-4ec9-852e-b76ccdedd930.jpg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>Faimly Tree Price 3000 Pkr</b></small> </p>
                        <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/1a8e74ac-1ffe-4da4-88fd-f8b55a2d446a.jpg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>Passport Copy Price 4000 Pkr</b></small> </p>
                       <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/42f193c3-69ea-4e2f-8e26-0ad7da9a1461.jpg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>Cdr All Network Price 3500</b></small> </p>
                        <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/0af2df5c-6423-43ea-ac9e-c13766e6107f.jpg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>FRC Nadra Price 7000 Pkr</b></small> </p>
                       <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/f83a25db-2e97-4ea4-9a94-0455138c293a.jpg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>Nadra Pic Price 550 Pkr</b></small> </p>
                        <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/31a16ba5-e1f9-4864-bd50-60b735031aff.jpg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>fir Copy price 4000 Pkr</b></small> </p>
                       <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/58aacfcf-7f34-4dd8-aaa9-8cff3024c152.jpg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>Uk Sim Price 5500</b></small> </p>
                        <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        <div class="card col-md-4 col-12">
            <div class="card-content">
                <div class="card-body"> <img style="width:100%;height: 400px;" class="img" src="images/bd016189-a21e-4c7d-8130-d5b81a377ec2.jpg" />
                    <div class="shadow"></div>
                    <div class="card-title"> </div>
                    <div class="card-subtitle">
                        <p> <small class="text-muted"><b>Pinpoint 📍 Location Price 2000 Pkr</b></small> </p>
                        <style>
    .slide {
        transition: transform 0.5s ease;
    }

    .slide:hover {
        transform: translateX(20px); /* Default slide distance */
    }

    @media (max-width: 768px) {
        .slide:hover {
            transform: translateX(10px); /* Slide distance for smaller screens */
        }
    }

    @media (max-width: 576px) {
        .slide:hover {
            transform: translateX(5px); /* Slide distance for even smaller screens */
        }
    }
</style>

<a href="https://wa.me/+9203020734457" class="btn btn-primary slide">BUY NOW</a>

                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <br>
    <a href="/" class="btn btn-primary">Home</a>
</div>

</body>
</html>