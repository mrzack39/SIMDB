<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing: border-box;
}

.columns {
  float: left;
  width: 33.3%;
  padding: 8px;
}

.price {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  border-radius: 5px;
  overflow: hidden;
}

.price:hover {
  box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2);
}

.price .header {
  background-color: #111;
  color: white;
  font-size: 25px;
  padding: 20px;
}

.price li {
  border-bottom: 1px solid #eee;
  padding: 20px;
  text-align: center;
}

.price .grey {
  background-color: #eee;
  font-size: 20px;
}

.button {
  background-color: #04AA6D;
  border: none;
  color: white;
  padding: 10px 25px;
  text-align: center;
  text-decoration: none;
  font-size: 18px;
  display: block;
}

@media only screen and (max-width: 600px) {
  .columns {
    width: 100%;
  }
}
</style>
</head>
<body>

<h2 style="text-align:center">Select Your Plan</h2>
<div class="columns">
  <ul class="price">
    <li class="grey"><a href="https://simdb.live/index.php" class="button">Home</a></li>
<div class="columns">
  <ul class="price">
    <li class="header" style="background-color:#04AA6D">Free</li>
    <li class="grey">Demo Check</li>
    <li>Jazz Data Franchise</li>
    <li>Zong Data Franchise</li>
    <li>Ufone Data Franchise</li>
    <li>Warid Data Franchise</li>
    <li>Telenor Data Franchise</li>
    <li class="grey"><a href="https://simdb.live/index.php" class="button">Demo Check</a></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">Premium</li>
    <li class="grey">$15 Monthly</li>
    <li>150 coins</li>
    <li>Jazz Data Franchise</li>
    <li>Zong Data Franchise</li>
    <li>Ufone Data Franchise</li>
    <li>Warid Data Franchise</li>
    <li>Telenor Data Franchise</li>
    <li>Punjab vehicle Data </li>
    <li>Islamabad vehicle Data</li>
    <li>Sindh vehicle Data</li>
    <li class="grey"><a href="https://wa.me/+9203020734457" class="button">Contact Now</a></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">Searching Rates</li>
    <li class="grey">Per Number 10 coins</li>
    <li>Per Cnic 10 coins</li>
    <li>All Network Data Franchise</li>
    <li>Jazz Data Franchise</li>
    <li>Zong Data Franchise</li>
    <li>Ufone Data Franchise</li>
    <li>Warid Data Franchise</li>
    <li>Telenor Data Franchise</li>
    <li>Punjab vehicle Data 50 coins</li>
    <li>Islamabad vehicle Data 50 coins</li>
    <li>Sindh vehicle Data 50 coins</li>
    <li>Vehicles Data Apko Whats app per dia jay ga</li>
    <li class="grey"><a href="https://wa.me/+9203020734457" class="button">Contact Now</a></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="grey"><a href="https://simdb.live/index.php" class="button">Back</a></li>
</body>
</html>