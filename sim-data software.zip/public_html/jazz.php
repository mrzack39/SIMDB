<?php
// Initialize the session
session_start();
require "functions.php";

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}




$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// if( (!isset($_SESSION["username"]))  && (!isset($_SESSION["is_user_login"])) )
// {
//     header("Location: ../login/index.php"); 
// }
// if(isset($_POST["search"]))
// {
//     $output = fetchRecord();
// }

if(isset($_POST["new"]))
{
    header("Location:".$_SERVER["REQUEST_URI"]);
}
if(isset($_POST["search"]))
{
    if (!empty($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {

        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit();
    }else{
        
         $output = fetchRecordUsingLink($_POST["number"]);
    $remainingCoins = getTotalCoins();
    } 
    
   

}
$remainingCoins = getTotalCoins();
$CoinsExpiry =  getCoinsExpiry(); ;


$updatedExpiry = '';

if (!empty($CoinsExpiry) && $CoinsExpiry !== "Buy Now") {
    $expiryDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $CoinsExpiry);

    if ($expiryDateTime instanceof DateTime) {
        $expiryDateTime->add(new DateInterval('P30D'));
        $updatedExpiry = $expiryDateTime->format('Y-m-d H:i:s');
    }  
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Search For Info</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
  <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script> 
  
<style>
 

#pageloader
{
  background: rgba( 255, 255, 255, 0.8 );
  height: 100%;
  display:none;
  position: relative;
  width: 100%;
  z-index: 9999;
}

#pageloader img
{
  position: absolute;
  margin-left: 35%;
  margin-top: 30%;
  width:auto;
  max-height:100px;
}
body{
    overflow-x: hidden;
}

@media screen and (max-width: 576px) {
#pageloader img
{
  position: absolute;
  margin-left: 10%;
  margin-top: 70%;
  width:auto;
  max-height:100px;
}

/*.table-bordered td, .table-bordered th {
    border: 1px solid #dee2e6;
    word-wrap: break-word;
    width: 10%;
}
    */
}
  
 
 

</style>
</head>

<body>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-12">
                <div id="pageloader">
                    <img src= "form_loader.gif"/>
                </div>
            </div>
        </div>
    </div>
 
 <?php include('header.php'); ?>
 
  
  <div id="google_translate_element"></div>

<div class="row mt-4 justify-content-center">
    <div class="col-md-6">
        <div class="alert alert-primary font-weight-bold text-center">Username: <?php if(isset($_SESSION["username"])){echo $_SESSION["username"];}?> </div>
    </div>

</div>

<div class="container col-md-6" id="cont">
  <div class="jumbotron" style="background-image: url('../assets/images/background7.jpg')">
    <div class="row d-flex justify-content-center" >
      <div class="col-md-12 ">
        <form method="POST" id="myform"> 
          <div class="form-group col-md-12">
               <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
              <center> <b><p>Only Jazz-warid Number Search</p><p></p>
               <p></p></b></center>
              <div class="col-sm-12" style="text-align:center;">
                  <label>Your Remaining Coins <br> <span style="font-size:22px;" class="badge badge-primary"><?= $remainingCoins ?> </span></label>
                  <br>
                  <label>Coins Purchase Date <br> <span style="font-size:22px;" class="badge badge-primary"><?= $CoinsExpiry ?> </span></label>
                   <br>
                  <label>Coins Expiry Date <br> <span style="font-size:22px;" class="badge badge-primary" id="countdown"> </span></label>
                 
              </div>
          </div>
          <hr/>
          
          <div class="form-group col-md-12">
            <input type="number" name="number" id="num"  class="form-control" placeholder="Enter Jazz-warid Number" >
          </div>
          <div class="form-group col-md-12" > 
            <button type="submit" name="search" id="save" class="btn btn-primary" style="width:100%;margin-bottom:5px;">Search</button>
          

            <button type="submit" name="new" class="btn btn-lg btn-primary" style="width:100%;margin-bottom:5px;">New Search</button>
          </div>
          </div>
        </form>
      </div>
      </div>

    </div>
</div>

<div class="row mt-3 d-flex justify-content-center" >
    <div class="col-md-6" style="text-align:center;">
<?php 
            if( (isset($output)) && (strlen($output) > 0) ) { 
                echo'<button class="btn btn-success" id="downloadImage">Download as PNG</button>';
            }
                ?>
        </div>
        </div>
                
  <div class="row mt-3 d-flex justify-content-center" id="printdiv" style="
    display: flex !important;
    justify-content: flex-start !important;
    align-items: center !important;">
    <div class="col-md-6">
      
            <?php 
            if( (isset($output)) && (strlen($output) > 0) ) { 
                echo $output;
               // deleteMyCoins(1);
                unset($output);
                unset($_POST);
            }
            ?>
        
      </table>
      </div>
  </div>

  </div>
<script>
$(document).ready(function(){
    $("#myform").on("submit", function(event){
        var enteredNumber = $("#num").val().trim();
        
        // Debug: Log the entered number
        console.log("Entered Number:", enteredNumber);

        // Extract first three digits of the number
        var firstThreeDigits = enteredNumber.substring(0, 3);
        
        // Debug: Log the first three digits
        console.log("First Three Digits:", firstThreeDigits);
        
        // Define Jazz-warid prefixes
        var jazzPrefixes = ['300', '301', '302', '303', '304', '305', '306', '307', '308', '309','320', '321', '322', '323', '324','325', '326', '327', '328'];
        
        // Check if the first three digits match any Jazz-warid prefix
        if (!jazzPrefixes.includes(firstThreeDigits)) {
            alert("Please search Jazz-warid numbers only. Click on okay and reload page again");
            event.preventDefault(); // Prevent form submission
            
            // Debug: Log that the validation failed
            console.log("Validation Failed: Not a Jazz-warid number");
            return false;
        }
        
        // Debug: Log that the validation passed
        console.log("Validation Passed: Jazz-warid number detected");

        $("#cont").css("opacity", "0.3");
        $("#pageloader").show();
        return true; // Allow form submission
    });
});
     var $ = jQuery;
  $(document).ready(function(){
      $("#myform").on("submit", function(){
            $("#cont").css("opacity","0.3");
            $("#pageloader").show();
            return true;
      });//submit
    
});

    var expiryDate = new Date("<?php echo $updatedExpiry; ?>").getTime();
    
    if('<?php echo $updatedExpiry; ?>' == '' || '<?php echo $updatedExpiry; ?>' == undefined ){
        
        $("#countdown").html('<a href="https://wa.me/+9203207483733" style="text-decoration:none;color:white;cursor:pointer" target="_blank">Buy Now</a>');
    }
    else{
    var x = setInterval(function() {
        var now = new Date().getTime();
        var distance = expiryDate - now;
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        $("#countdown").text(days + "d " + hours + "h " + minutes + "m " + seconds + "s ");

        if (distance < 0) {
            clearInterval(x);
            $("#countdown").text("Expired");
        }
    }, 1000);
    }
    
    function getCurrentDateTime() {
      var now = new Date();
      var day = ("0" + now.getDate()).slice(-2);
      var month = ("0" + (now.getMonth() + 1)).slice(-2);
      var year = now.getFullYear();
      var hours = ("0" + now.getHours()).slice(-2);
      var minutes = ("0" + now.getMinutes()).slice(-2);

      return year + "-" + month + "-" + day + "_" + hours + ":" + minutes;
    }
    
    
    $(document).on('click','#printImage',function(){
        
        var printContents = $('#printdiv').html();
        var printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>Print</title></head><body>' + printContents + '</body></html>');
        printWindow.document.close();
        printWindow.print();
        printWindow.document.close();
        
    });
    
     $(document).on('click','#downloadImage',function(){
        
  
    var element = document.getElementById('printdiv');

     html2canvas(element, { logging: true, scale: 2 }).then(function (canvas) {
        var imgData = canvas.toDataURL('image/png');
        var fileName = 'simdb-' + getCurrentDateTime() + '.png';

        var link = document.createElement('a');
        link.href = imgData;
        link.download = fileName;
        link.click();
    });
   
   
        
    });
    
    /* function googleTranslateElementInit() {
      new google.translate.TranslateElement({
        pageLanguage: 'en',
        includedLanguages: 'en,ur',
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE
      }, 'google_translate_element');
    }
    */
 

 if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
    </script>
</body>
</html>