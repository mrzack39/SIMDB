<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
*/
function fetchRecord()
{
    $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
        if(count($_POST) > 0) 
        {
            $arr = array();
            $opr = strtolower(substr($_POST["operator"], 0 , 1));
            $tables_query = mysqli_query($conn,"SELECT table_name FROM information_schema.tables WHERE table_schema = 'zohafab_bb' AND table_name LIKE '$opr%' ORDER BY table_name asc;");
            if(mysqli_num_rows($tables_query) > 0)
            {
                while($row0 = mysqli_fetch_assoc($tables_query) )
                {
                    $table_name =  $row0["table_name"];
                    $number= trim($_POST["number"] , " " );
                    if( strlen($number) == 10)
                    {
                        $result = mysqli_query($conn,"SELECT * FROM `$table_name` where `Mobile` = '$number' ");
                        if(mysqli_num_rows($result) > 0 )
                        {
                            while($row = mysqli_fetch_assoc($result)) 
                            {
                                array_push($row, ucfirst($_POST["operator"]) );
                                array_push($arr , $row);
                                unset($row);
                            }
                            break;
                        }
                    }else if(strlen($number) == 13)
                    {
                        $result = mysqli_query($conn,"SELECT * FROM `$table_name` where `Cnic` = '$number' ");
                        if(mysqli_num_rows($result) > 0 )
                        {
                            while($row = mysqli_fetch_assoc($result))
                            {
                                array_push($row, ucfirst($_POST["operator"]) );
                                array_push($arr , $row);
                                unset($row);
                            }
                            continue;
                        }
                    }else{ break;}
                    
                }
            }
            if( (getTotalCoins() == 0) && (checkSpecialAccess() == false) )
            {
                return '
                <tr><td class="bg-danger text-white" colspan=2>Coins limit exceeded</td></tr>';
            }
            else if( (checkSpecialAccess() == true) || (getTotalCoins() > 0) )
            {
                $output = '';
                if(count($arr) > 0)
                {
                    for($i = 0;$i < count($arr);$i++)
                    {
                        $output .= '
                        <tr style="background-color:gold;font-weight:bold;">
                        <td><i>Mobile No</i></td>
                        <td>'.$arr[$i]["Mobile"].'</td>
                    </tr>
                    <tr>
                        <td><i>Name</i></td>
                        <td>'.$arr[$i]["Name"].'</td>
                    </tr>
                    <tr>
                        <td><i>CNIC</i></td>
                        <td>'.$arr[$i]["CNIC"].'</td>
                    </tr>
                    <tr>
                        <td><i>Address</i></td>
                        <td>'.$arr[$i]["Address"].'</td>
                    </tr>';        
                    }
                    return $output;
                }
            }
        }
}


function fetchRecordUsingLink($number)
{
    
    if(strlen($number) == 13 && getTotalCoins() < 20){
      return '<tr><td class="bg-danger text-white" colspan="5">Coins limit exceeded one</td></tr>';
    }else if(getTotalCoins() < 20){
        return '<tr><td class="bg-danger text-white" colspan="5">Coins limit exceeded</td></tr>';   
    }
    
    
    if ((getTotalCoins() == 0) && (checkSpecialAccess() == false)) {
        return '<tr><td class="bg-danger text-white" colspan="5">Coins limit exceeded</td></tr>';
    
        
    } else if ((checkSpecialAccess() == true) || (getTotalCoins() > 0)) {
        
        
        $url = "https://persontrace.com/api/customers";

        $data = array(
            "user" => "developer",
            "token" => "ASDB[M-)!12n_oO4:f0IhoU=)%",
            "number" => $number //"3002384120"
        );
    }

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($response === false) {
            echo "Request failed: " . curl_error($ch);
        } else {
            // echo "HTTP Status Code: " . $http_status . "\n";
            //echo "Response data:\n";
          //  echo $response;
        }

        curl_close($ch);
        
         $arrayData = json_decode($response, true);
        $data = $arrayData;
}
$folderPath = 'User_Search_Logs';
if (!file_exists($folderPath)) {
    mkdir($folderPath, 0777, true);
}

$filename = $folderPath . '/' . date('d-m-Y') . '.json';
$data['timestamp'] = date('Y-m-d H:i:s');

// Encode the data to JSON format
$jsonData = json_encode($data, JSON_PRETTY_PRINT);

// Append the JSON data to the file
file_put_contents($filename, $jsonData, FILE_APPEND);

        
    //echo"=====".$arrayData['data'][0]['mobile'];
    
   $firstThreeLetters = '';
if (isset($arrayData['data'][0]['mobile'])) {
    $firstThreeLetters = substr($arrayData['data'][0]['mobile'], 0, 3);
}

// Initialize variables
$newdesign = 0;
$cus_style = '';
$image = '';

// Check the value of $firstThreeLetters and set styles/images accordingly
if (in_array($firstThreeLetters, array('300', '301', '302','303','304','305','306','307','308','309','325','326','327','328'))) {
    // Jazz
    $cus_style = 'style="background:#d71a20;color:white;"';
    $image = '<img src="../images/jazz.png" style="height: 25px;width: 25px;">'; 
} else if (in_array($firstThreeLetters, array('320', '321', '322','323','324'))) {
    // Warid
    $cus_style = 'style="background:#d71a20;color:white;"';
    $image = '<img src="../images/warid.jpg" style="height: 28px;width: 28px;">'; 
} else if (in_array($firstThreeLetters, array('330', '331', '332', '333', '334', '335', '336', '337', '338', '339'))) {
    // Ufone
    $newdesign= 1;
    $cus_style = 'style="background:#d71a20;color:white;"';
    $image = '<img src="../images/ufone.jpg" style="height: 105px;width: 180px;background:white;">'; 
} else if (in_array($firstThreeLetters, array('310', '311', '312', '313', '314', '315', '316', '317', '318', '319'))) {
    // Zong
    $newdesign =1;
    $cus_style = 'style="background:#d71a20;color:white;"';
    $image = '<img src="../images/zong.png" style="height: 61px;width: 143px;background:white;">'; 
} else if (in_array($firstThreeLetters, array('340', '341', '342', '343', '344', '345', '346', '347', '348', '349'))) {
    // Telenor
    $newdesign =1;
    $cus_style = 'style="background:#d71a20;color:white;"';
    $image = '<img src="../images/telenor.png" style="height: 61px;width: 143px;background:white;">'; 
}

// Check if mobile number is set and perform actions based on its length
if (isset($arrayData['data'][0]['mobile'])) {
    $number = $arrayData['data'][0]['mobile'];
    if (strlen($number) == 13) {
        $newdesign = 0;
        deleteMyCoins(20);
    } else {
        deleteMyCoins(40);
    }
}

    
    
    if($newdesign == 1){
        $output = '<div class="container mt-4">
            <h2>Result</h2>
            <div class="table-responsive">
            '.$image.'
            <table>
            <tr>
            <td style="width: 347px;"> <br> MOBILE#: '.$arrayData['data'][0]['mobile'].' <br> 
Certified that a sum of<br>
Rupees On account of Income<br>
Tax has been<br>
collected/deducted from<br>
(Name and address of the<br>
person from whom tax<br>
collected/deducted) having<br>
National Tax Number</td>
            <td style="vertical-align: baseline;text-align: center;">PART VII <br> Certificate of Collection or Deduction of Tax <br> (See Rule 42) <br>  Certified that a sum of Original/Duplicate Date of issue. '.date('j M Y').' <br>
             '.$arrayData['data'][0]['name'].' 
            <br>
            0
            </td>
            </tr>
            <tr>
            <td >holder of CNIC no. <br> ON <br> OR during the period from *
            <br> On account of *
             <br> vide
              <br> On the value/amount of Reupees
              <br>
            </td>
             <td style="text-align:center"> '.$arrayData['data'][0]['cnic'].' <br> <br> 01-jul-2021 To 30-jun-2022 <br> Mobile phone users and Prepaid cards </td>
            </tr>
            <tr>
            <td colspan="2">
            This is to further certify that the tax collected/deducted has been deposited in the Federal Government Account as per the following details: 
            </td>
            </td>
            </table>
            
            
            </div>
            <br><br><br>
            ';  
            
    }
    else{
    
        $output = '<div class="container mt-4">
            <h2 >Result</h2>
            <div class="table-responsive" style="width:800px !important;">
                <table class="table table-bordered table-hover thead-dark" >
                    <thead '.$cus_style.'>
                        <tr>
                            <th>Mobile</th>
                            <th>Name</th>
                            <th>CNIC</th>
                            <th>Address</th>
                            <th>Status</th>
                            <th>Brand</th>
                        </tr>
                    </thead>
                    <tbody>';
}
       // Initialize the output variable
$output = '';

if (isset($arrayData['data']) && is_array($arrayData['data'])) {
    foreach ($arrayData['data'] as $record) {
        // Ensure necessary fields are set
        $status = isset($arrayData['status']) ? $arrayData['status'] : '';
        $mobile = isset($record['mobile']) ? $record['mobile'] : '';
        $name = isset($record['name']) ? $record['name'] : '';
        $cnic = isset($record['cnic']) ? $record['cnic'] : '';
        $address = isset($record['address']) ? $record['address'] : '';

        // Extract the first three digits of the mobile number
        $firstThree = substr($mobile, 0, 3);

        // Determine the image to display based on the first three digits
        if (in_array($firstThree, array('300', '301', '302', '303', '304', '305', '306', '307', '308', '309', '325', '326', '327', '328'))) {
            $image = '<img src="/images/jazz.png" style="height: 25px;width: 25px;">';
        } else if (in_array($firstThree, array('320', '321', '322', '323', '324'))) {
            $image = '<img src="/images/warid.jpg" style="height: 28px;width: 28px;">';
        } else if (in_array($firstThree, array('310', '311', '312', '313', '314', '315', '316', '317', '318', '319'))) {
            $image = '<img src="/images/zong.png" style="height: 25px;width: 25px;background:white;">';
        } else if (in_array($firstThree, array('340', '341', '342', '343', '344', '345', '346', '347', '348', '349'))) {
            $image = '<img src="/images/telenor.png" style="height: 25px;width: 25px;background:white;">';
        } else if (in_array($firstThree, array('330', '331', '332', '333', '334', '335', '336', '337', '338', '339'))) {
            $image = '<img src="/images/ufone.jpg" style="height: 28px;width: 30px;background:white;">';
        } else {
            $image = ''; // default to no image if no match
        }

        // Generate the HTML table rows
        $output .= '
            <tr>
                <td>' . $mobile . '</td>
                <td>' . $name . '</td>
                <td>' . $cnic . '</td>
                <td>' . $address . '</td>
                <td> Active </td>
                <td>' . $image . '</td>
            </tr>';
    }

    // Close the HTML table and return the output
    $output .= '</tbody>
            </table>
        </div>
    </div>';
} else {
    $output = '<div>No data available.</div>';
}

return $output;


function getCoinsExpiry()
{
    $conn = mysqli_connect("localhost", "simdcfob_aa", "simdcfob_aa", "simdcfob_aa");
    
    $id = isset($_SESSION["id"]) ? $_SESSION["id"] : NULL;
    
    if ($id != NULL)
    {
        $result = mysqli_query($conn, "SELECT * FROM `transaction_history` WHERE `to_user` = '$id' ORDER BY `sent_time` DESC LIMIT 1");
        
        if (mysqli_num_rows($result) > 0)
        {
            while ($row = mysqli_fetch_assoc($result)) 
            {
                $coinsexpiry = $row["sent_time"];
                return $coinsexpiry;
            }
        }
    }
    
    // Return "Buy Now" if there are no results or $id is NULL
    return '<a href="https://wa.me/+923207483733" style="text-decoration:none;color:white;cursor:pointer" target="_blank">Buy Now</a>';
}


function getTotalCoins()
{
    $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $result = mysqli_query($conn,"SELECT * FROM `users` where `id` = '$id' LIMIT 1 ");
        if(mysqli_num_rows($result) > 0 )
        {
            while($row = mysqli_fetch_assoc($result)) 
            {
                $coins = (int) $row["coins"];
                return $coins;
            }
        }
    }
}


function checkSpecialAccess()
{
    $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $result = mysqli_query($conn,"SELECT * FROM `users` where `id` = '$id' LIMIT 1 ");
        if(mysqli_num_rows($result) > 0 )
        {
            while($row = mysqli_fetch_assoc($result)) 
            {
                if( strval($row["special_access"]) == "1")
                {
                    return true;
                }else { return false; } 
            }
        }
    }
}


/*function deleteMyCoins($quantity)
{
    $conn = mysqli_connect("localhost","simdcfob_cc","simdcfob_cc","simdcfob_cc");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $result = mysqli_query($conn,"SELECT * FROM `users` where `id` = '$id' LIMIT 1 ");
        if(mysqli_num_rows($result) > 0 )
        {
            while($row = mysqli_fetch_assoc($result)) 
            {
                $coins = (int) $row["coins"];
                if( ($coins >= $quantity) )
                {
                    $coins = $coins-$quantity;
                    $result1 = mysqli_query($conn,"UPDATE `users` SET coins = '$coins' WHERE `id` ='$id' ");
                    if(mysqli_num_rows($result1) > 0 )
                    {
                        return true;
                    }
                }else 
                {
                    return false;
                }
            }
        }
    }
}*/

/*function shareCoins($username,$quantity)
{
    if(checkSpecialAccess() == true)
    {
         return '<div class="alert alert-danger">You cannot share coins because you have special Account</div>';
    }else
    {
        $conn = mysqli_connect("localhost","simdcfob_cc","simdcfob_cc","simdcfob_cc");
        if(getTotalCoins() >= ($quantity+1))
        {
            $result = mysqli_query($conn,"SELECT * FROM `users` where `username` = '$username' LIMIT 1 ");
            if(mysqli_num_rows($result) > 0 )
            {
                while($row = mysqli_fetch_assoc($result)) 
                {
                    $user_id = $row["id"];
                    $coins = (int) $row["coins"];
                    $coins = $coins + $quantity+1;
                    $result1 = mysqli_query($conn,"UPDATE `users` SET `coins` = '$coins' WHERE `username`='$username' ");
                    if($result1)
                    {
                        deleteMyCoins($quantity+1);
                        insertTransaction($user_id,$quantity+1);
                            return '<div class="alert alert-success">Coins Transferred Successfully</div>';
                    }else
                    {
                         return '<div class="alert alert-danger">System Error. Unable to share Coins</div>';
                    }
                }
            }else
            {
                 return '<div class="alert alert-danger">Username Does not exist</div>';
            }
            
        }else
        {
            return '<div class="alert alert-danger">Your Account Does not have required Coins to Share.</div>';
        }
    }
}

*/

function deleteMyCoins($quantity)
{
    
    $conn = mysqli_connect("localhost", "simdcfob_aa", "simdcfob_aa", "simdcfob_aa");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"] : NULL;

    if ($id !== NULL) {
        $result = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1 ");

        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $coins = (int) $row["coins"];

                if ($coins >= $quantity) {
                    $coins -= $quantity;
                    
                    $result1 = mysqli_query($conn, "UPDATE `users` SET coins = '$coins' WHERE `id` ='$id' ");

                    // Check if the update query was successful
                    if ($result1) {
                        // Check how many rows were affected by the update
                        if (mysqli_affected_rows($conn) > 0) {
                            return true;
                        } else {
                            // Handle the case where the update did not affect any rows
                            return false;
                        }
                    } else {
                        // Handle the case where the update query fails
                        return false;
                    }
                } else {
                    // Handle the case where there are not enough coins
                    return false;
                }
            } else {
                // Handle the case where no rows were returned
                return false;
            }
        } else {
            // Handle the case where the query fails
            return false;
        }
    } else {
        // Handle the case where $id is NULL
        return false;
    }

    // Close the database connection
    mysqli_close($conn);
}


function shareCoins($username, $quantity)
{
    if (checkSpecialAccess() == true) {
        return '<div class="alert alert-danger">You cannot share coins because you have special Account</div>';
    } else {
        $conn = mysqli_connect("localhost", "simdcfob_aa", "simdcfob_aa", "simdcfob_aa");

        // Check if the connection was successful
        if (!$conn) {
            return '<div class="alert alert-danger">Database connection error: ' . mysqli_connect_error() . '</div>';
        }
 
 echo 'Came'.$quantity;
        if (getTotalCoins() >= ($quantity + 1)) {
            $result = mysqli_query($conn, "SELECT * FROM `users` WHERE `username` = '$username' LIMIT 1 ");

            // Check if the query was successful
            if ($result) {
                // Check if any rows were returned
                if (mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_assoc($result);
                    $user_id = $row["id"];
                    $coins = (int) $row["coins"];
                    $coins = $coins + $quantity + 1;

                    $result1 = mysqli_query($conn, "UPDATE `users` SET `coins` = '$coins' WHERE `username`='$username' ");

                    // Check if the update query was successful
                    if ($result1) {
                        deleteMyCoins($quantity + 1);
                        insertTransaction($user_id, $quantity + 1);
                        return '<div class="alert alert-success">Coins Transferred Successfully</div>';
                    } else {
                        // Handle the case where the update query fails
                        return '<div class="alert alert-danger">System Error. Unable to share Coins</div>';
                    }
                } else {
                    // Handle the case where no rows were returned
                    return '<div class="alert alert-danger">Username Does not exist</div>';
                }
            } else {
                // Handle the case where the query fails
                return '<div class="alert alert-danger">Error fetching user data: ' . mysqli_error($conn) . '</div>';
            }
        } else {
            return '<div class="alert alert-danger">Your Account Does not have required Coins to Share.</div>';
        }

        // Close the database connection
        mysqli_close($conn);
    }
}

function fetchKarachiVehicleRecord()
{
    $conn = mysqli_connect("localhost","simdcfob_aa","simdcfob_aa","simdcfob_aa");
        if(count($_POST) > 0) 
        {
            $arr = array();
            $tbr = array();
            $number = trim($_POST["number"] , ' ');
            $query = mysqli_query($conn,"SELECT * FROM `2wr_1950_2017` WHERE `regno`='$number' OR `cnic`='$number' ");
            if(mysqli_num_rows($query) > 0)
            {
                while($row = mysqli_fetch_array($query,MYSQLI_NUM))
                {
                    array_push($arr,$row);
                    unset($row);
                }
                  $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='punjabfata_bb' AND `TABLE_NAME`='2wr_1950_2017';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
            }else
            {
                $query1 = mysqli_query($conn,"SELECT * FROM `4w_1950_2017` WHERE `regno`='$number' OR `cnic`='$number' ");
                if(mysqli_num_rows($query1) > 0)
                {
                    while($row = mysqli_fetch_array($query1,MYSQLI_NUM))
                    {
                        array_push($arr,$row);
                        unset($row);
                    }
                      $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='punjabfata_bb' AND `TABLE_NAME`='4w_1950_2017';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
                }
            }
            
           if( (getTotalCoins() == 0) && (checkSpecialAccess() == false) )
            {
                return '
                <tr><td class="bg-danger text-white" colspan=2>Coins limit exceeded</td></tr>';
            }
            else if( (checkSpecialAccess() == true) || (getTotalCoins() > 0) )
            {
                $output = '';
                if(count($arr) > 0)
                {
                
                    for($i = 0;$i < count($arr[0]);$i++)
                    {
                        if( strtolower($tbr[0][$i]) == "id" )
                        {
                            continue;
                        }
                        $output .= $tbr[0][$i];
                        if( trim(strtolower($tbr[$i][0]) , ' ') == "regno")
                        {
                             $output .= '
                                <tr  class="bg-primary text-white" style="font-weight:bold;">
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';   
                        }else
                        {
                            $output .= '
                                <tr>
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';
                        }
                    }
                    
                    
                    return $output;
                }
            }
        }
}

function fetchPunjabVehicleRecord()
{
    $conn = mysqli_connect("localhost","simdcfob_cc","simdcfob_cc","simdcfob_cc");
        if(count($_POST) > 0) 
        {
            $arr = array();
            $tbr = array();
            $number = trim($_POST["number"] , ' ');
            $query = mysqli_query($conn,"SELECT * FROM `Sheet 1` WHERE `VEH_REG_NO`='$number' OR `cnic`='$number' ");
            if(mysqli_num_rows($query) > 0)
            {
                while($row = mysqli_fetch_array($query,MYSQLI_NUM))
                {
                    array_push($arr,$row);
                    unset($row);
                }
                  $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='ptracker_bb' AND `TABLE_NAME`='Sheet 1';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
            }else
            {
                $query1 = mysqli_query($conn,"SELECT * FROM `Sheet 47` WHERE `VEH_REG_NO`='$number' OR `cnic`='$number' ");
                if(mysqli_num_rows($query1) > 0)
                {
                    while($row = mysqli_fetch_array($query1,MYSQLI_NUM))
                    {
                        array_push($arr,$row);
                        unset($row);
                    }
                      $table = mysqli_query($conn,"SELECT `COLUMN_NAME`  FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='ptracker_bb' AND `TABLE_NAME`='Sheet 47';");
                    if(mysqli_num_rows($table) > 0)
                        {
                            while($row = mysqli_fetch_array($table,MYSQLI_NUM))
                            {
                                array_push($tbr,$row);
                                unset($row);
                            }
                        }
                }
            }
            
           if( (getTotalCoins() == 0) && (checkSpecialAccess() == false) )
            {
                return '
                <tr><td class="bg-danger text-white" colspan=2>Coins limit exceeded</td></tr>';
            }
            else if( (checkSpecialAccess() == true) || (getTotalCoins() > 0) )
            {
                $output = '';
                if(count($arr) > 0)
                {
                
                    for($i = 0;$i < count($arr[0]);$i++)
                    {
                        if( strtolower($tbr[0][$i]) == "id" )
                        {
                            continue;
                        }
                        $output .= $tbr[0][$i];
                        if( trim(strtolower($tbr[$i][0]) , ' ') == "regno")
                        {
                             $output .= '
                                <tr  class="bg-primary text-white" style="font-weight:bold;">
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';   
                        }else
                        {
                            $output .= '
                                <tr>
                                    <td><u>'.ucfirst($tbr[$i][0]).'</u></td>
                                    <td>'.$arr[0][$i].'</td>
                                </tr>
                                ';
                        }
                    }
                    
                    
                    return $output;
                }
            }
        }
}

function insertTransaction($to_user, $coins)
{
    $conn = mysqli_connect("localhost", "simdcfob_cc", "simdcfob_cc", "simdcfob_cc");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"] : NULL;

    if ($id !== NULL) {
        $result = mysqli_query($conn, "INSERT INTO `transaction_history` (`from_user`, `to_user`, `coins`) VALUES ('$id', '$to_user', '$coins') ");

        // Check if the insert query was successful
        if ($result) {
            return true;
        } else {
            // Handle the case where the insert query fails
            return false;
        }
    } else {
        // Handle the case where $id is NULL
        return false;
    }

    // Close the database connection
    mysqli_close($conn);
}


/*function insertTransaction($to_user,$coins)
{
      $conn = mysqli_connect("localhost","simdcfob_cc","simdcfob_cc","simdcfob_cc");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
    if( $id != NULL)
    {
        $result = mysqli_query($conn,"INSERT INTO `transaction_history` (`from_user`,`to_user`,`coins`) VALUES ('$id','$to_user','$coins') ");
        if(mysqli_num_rows($result) > 0 )
        {
            return true;
        }else { return false; }
    }
}*/


function getUsername($userid)
{
     $conn = mysqli_connect("localhost","simdcfob_cc","simdcfob_cc","simdcfob_cc");
$result = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '$userid' ");
     
    if(mysqli_num_rows($result) > 0 )
    {
        while($row =  mysqli_fetch_assoc($result))
        {
            $name =  htmlentities($row["username"]);
        }
        $conn->close();
        return $name;
    }else
    {
        return "";
    }
    
    
}

function showTransactions()
{
    $output = '';
       $conn = mysqli_connect("localhost","simdcfob_cc","simdcfob_cc","simdcfob_cc");
    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;
     $username = isset($_SESSION["username"]) ? $_SESSION["username"]: NULL;
    if( $id != NULL)
    {
        $result = mysqli_query($conn,"SELECT * FROM `transaction_history` WHERE `from_user` = '$id' OR `to_user` = '$id' AND DATE(sent_time) >= DATE(NOW()) - INTERVAL 30 DAY ");
        
        if(mysqli_num_rows($result) > 0 )
        {
            while($row = mysqli_fetch_assoc($result))
            {
                if($row["from_user"] == $id)
                {
                    $method = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="red" class="bi bi-arrow-up" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M8 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L7.5 2.707V14.5a.5.5 0 0 0 .5.5z"/>
                    </svg> Sent';
                }else
                {
                    $method = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green" class="bi bi-arrow-down" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z"/>
                    </svg> Received';
                }
                
                $from_user = getUsername( $row["from_user"] );
                $to_user = getUsername( $row["to_user"] );
                
                $time = date("H:m, d M",strtotime($row["sent_time"]));
                $output .= '<tr>
                  <td>'.$from_user.'</td>
                  <td>'.$to_user.'</td>
                  <td>'.$row["coins"].'</td>
                  <td>'.$time.'</td>
                  <td>'.$method.'</td>
                </tr>';
            }
            return $output;
        }else { return false; }
    }
    $conn->close();
}


?>