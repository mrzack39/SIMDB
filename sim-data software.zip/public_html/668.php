<!DOCTYPE html>
<html lang="en">
<center>
<head>
    <title>CHECK 668 SIMS</title>
    <button onclick="document.location='index.php'" style="background-color: blue; color: white; border: none; padding: 10px 20px; font-size: 16px; border-radius: 5px; cursor: pointer;">Dashbord</button>
</head>
<body>

	<iframe src="https://cnic.sims.pk/" width="1200" height="1050"></iframe>

</body>
<button onclick="document.location='index.php'" style="background-color: blue; color: white; border: none; padding: 10px 20px; font-size: 16px; border-radius: 5px; cursor: pointer;">Dashbord</button>
</center>
</html>
