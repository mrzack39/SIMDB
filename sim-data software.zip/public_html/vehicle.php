<?php
session_start();
require "functions.php";

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}


if(isset($_POST["searchForKarachi"]))
{
    $output = fetchKarachiVehicleRecord();
}
if(isset($_POST["searchForPunjab"]))
{
    $output = fetchPunjabVehicleRecord();
}

if(isset($_POST["new"]))
{
    header("Location:".$_SERVER["REQUEST_URI"]);
}

$remainingCoins = getTotalCoins();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Search For Info</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<style>

#pageloader
{
  background: rgba( 255, 255, 255, 0.8 );
  height: 100%;
  display:none;
  position: relative;
  width: 100%;
  z-index: 9999;
}

#pageloader img
{
  position: absolute;
  margin-left: 35%;
  margin-top: 30%;
  width:auto;
  max-height:100px;
}

@media screen and (max-width: 576px) {
#pageloader img
{
  position: absolute;
  margin-left: 10%;
  margin-top: 70%;
  width:auto;
  max-height:100px;
}
    
}
    
</style>
</head>

<body>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-12">
                <div id="pageloader">
                    <img src= "form_loader.gif"/>
                </div>
            </div>
        </div>
    </div>

 <?php include('header.php'); ?>
 

<div class="row mt-2 justify-content-center">
    <div class="col-md-6">
        <div class="alert alert-primary font-weight-bold text-center">Username: <?php if(isset($_SESSION["username"])){echo $_SESSION["username"];}?> </div>
    </div>
</div>    
  

<div class="container col-md-6" id="cont">
     <ul class="nav nav-tabs" id="myTab" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">For Punjab</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="isb-tab" data-toggle="tab" href="#isb" role="tab" aria-controls="isb-tab" aria-selected="true">For Islamabad</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">For Sindh</a>
      </li>
    </ul>
    
    <div class="jumbotron" style="background-image: url('../assets/images/background7.jpg')">
        
       
        <div class="tab-content" id="myTabContent">
          <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
              <h5 class="text-center">Vehicle Search For Punjab</h5>
              <div class="row d-flex justify-content-center" >
            <div class="col-md-12 ">
                <form method="POST" id="myform">
                    <div class="form-group col-md-12">
                        <div class="col-md-8">
                            <label>Your Remaining Coins: <span style="font-size:22px;" class="badge badge-primary"><?= $remainingCoins ?> </span></label>
                         </div>
                    </div>
                    <hr/>
                      <div class="form-group col-md-12">
                        <label>Reg Number/ CNIC</label>
                        <input type="text" name="number" id="num" class="form-control" placeholder="ABC-123 ">
                      </div>
                    <div class="form-group col-md-12"> 
                        <button type="submit" name="searchForPunjab" id="save" class="btn btn-primary">Search</button>
                        <div class="d-flex justify-content-end">
                            <button type="submit" name="new" class="btn btn-lg btn-success">New Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
          </div>
          <div class="tab-pane fade show" id="isb" role="tabpanel" aria-labelledby="isb-tab">
              <h5 class="text-center">Vehicle Search For Islamabad</h5>
              <div class="row d-flex justify-content-center" >
            <div class="col-md-12 ">
                <form method="POST" id="myform">
                    <div class="form-group col-md-12">
                        <div class="col-md-8">
                            <label>Your Remaining Coins: <span style="font-size:22px;" class="badge badge-primary"><?= $remainingCoins ?> </span></label>
                         </div>
                    </div>
                    <hr/>
                      <div class="form-group col-md-12">
                        <label>Reg Number/ CNIC</label>
                        <input type="text" name="number" id="num" class="form-control" placeholder="ABC-123 ">
                      </div>
                    <div class="form-group col-md-12"> 
                        <button type="submit" name="searchForPunjab" id="save" class="btn btn-primary">Search</button>
                        <div class="d-flex justify-content-end">
                            <button type="submit" name="new" class="btn btn-lg btn-success">New Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
          </div>
          <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
              
              
              <h5 class="text-center">Vehicle Search For Sindh</h5>
              <div class="row d-flex justify-content-center" >
                <div class="col-md-12 ">
                    <form method="POST" id="myform">
                        <div class="form-group col-md-12">
                            <div class="col-md-8">
                                <label>Your Remaining Coins: <span style="font-size:22px;" class="badge badge-primary"><?= $remainingCoins ?> </span></label>
                             </div>
                        </div>
                        <hr/>
                          <div class="form-group col-md-12">
                            <label>Reg Number / CNIC</label>
                            <input type="text" name="number" id="num" class="form-control" placeholder="ABC-123 ">
                          </div>
                        <div class="form-group col-md-12"> 
                            <button type="submit" name="searchForKarachi" id="save" class="btn btn-primary">Search</button>
                            <div class="d-flex justify-content-end">
                                <button type="submit" name="new" class="btn btn-lg btn-success">New Search</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
          
          </div>
        </div>
        
        
        
    </div>
</div>

  <div class="row mt-3 d-flex justify-content-center">
    <div class="col-md-6">
      <table class="table table-hover table-bordered text-center">
        <tbody id="data">
            <?php 
            if( (isset($output)) && (strlen($output) > 0) ) { 
                echo $output;
                deleteMyCoins(1);
                unset($output);
                unset($_POST);
            }
            ?>
        </tbody>
      </table>
      </div>
  </div>

  </div>

<script>
  $(document).ready(function(){
      $("#myform").on("submit", function(){
            $("#cont").css("opacity","0.3");
            $("#pageloader").show();
            return true;
  });//submit
  });
</script>

</body>
</html>