<!DOCTYPE html>
<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>


    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>




    <style>
        body {

            text-align: center;

            background-color: #f0f0f0;
            /* Light grey */

        }



        form {

            margin-bottom: 20px;

        }



        .output {

            text-align: left;

            margin: auto;

            width: 70%;

            background-color: #fff;
            /* White */

            border-radius: 5px;

            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            /* Light shadow */

            padding: 20px;

        }



        .output ul {

            list-style-type: none;

            padding: 0;

        }



        .output ul ul {

            list-style-type: none;

            padding-left: 0;

        }



        .output li {

            border: 1px solid #ccc;
            /* Light grey border */

            margin-bottom: 10px;

            padding: 10px;

            border-radius: 5px;

            background-color: #f9f9f9;
            /* Off-white */

        }



        .output li li {

            padding: 0;

            margin: 0;

        }



        .output strong {

            font-weight: bold;

            color: #333;
            /* Dark grey */

        }



        /* Apply styles to the entire table */

        table {

            width: 100%;

            border-collapse: collapse;

        }



        /* Style the table header */

        th {

            background-color: red;
            /* Light grey */

            color: #333;
            /* Dark grey */

            font-weight: bold;

            padding: 10px;

            border: 1px solid #ccc;
            /* Light grey border */

        }



        /* Style the table rows */

        td {

            padding: 10px;

            border: 1px solid #ccc;
            /* Light grey border */

        }



        /* Add alternating row colors */

        tr:nth-child(even) {

            background-color: #f9f9f9;
            /* Off-white */

        }



        /* Add hover effect on rows */

        tr:hover {

            background-color: #f2f2f2;
            /* Light grey */

        }


        .output {
            margin-bottom: 10px;
            padding-bottom: 5px;
        }


        .whatsapp-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #25d366;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s;
            z-index: 1000;
        }

        .whatsapp-button:hover {
            background-color: #128c7e;
        }

        .whatsapp-icon {
            margin-right: 10px;
            width: 20px;
            height: auto;
            vertical-align: middle;
        }

        /* Adjustments for small screens */
        @media (max-width: 600px) {
            .whatsapp-button {
                font-size: 14px;
                padding: 8px 16px;
                bottom: 10px;
                right: 10px;
            }

            .whatsapp-icon {
                width: 16px;
            }
        }
    </style>
</head>

<body>
    <a class="whatsapp-button" href="https://api.whatsapp.com/send?phone=923207483733" target="_blank">
        <img class="whatsapp-icon" src="https://pngimg.com/d/whatsapp_PNG95151.png" alt="WhatsApp Icon">
        Chat on WhatsApp
    </a>
</body>

</html>




<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



session_start();

require "functions.php";





if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {



    header("location: login.php");



    exit;
}







// Initialize variables



$output = '';


$remainingCoins = getTotalCoins(20);
$DeductMyCoinsMessage = '';
$DeductMyCoins = true;

$CoinsExpiry =  getCoinsExpiry();



$updatedExpiry = '';

if (!empty($CoinsExpiry) && $CoinsExpiry !== "Buy Now") {
    $expiryDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $CoinsExpiry);

    if ($expiryDateTime instanceof DateTime) {
        $expiryDateTime->add(new DateInterval('P30D'));
        $updatedExpiry = $expiryDateTime->format('Y-m-d H:i:s');
    }
}


$htmlOutput = '';







// Handle form submission



if (isset($_POST["search"])) {



    // Check if search input is not empty



    if (!empty($_POST["search_query"])) {



        $search_query = $_POST["search_query"];



        // Check if input is an 8-digit number



        if (preg_match('/^\d{8}$/', $search_query)) {



            // Fetch data from API



            $number = $_POST["search_query"];



            $api_url = 'https://tracerpk.com/testnew.php/?id=' . $number;



            $api_response = file_get_contents($api_url);



            if ($api_response !== false) {







                // Parse JSON response



                $data = json_decode($api_response, true);



                if (is_array($data) && !empty($data)) {



                    if (!DeductMyCoins(40)) {
                        $DeductMyCoins = false;
                        $DeductMyCoinsMessage = "<b style='color:red'>Not enough coins</b>";
                    }
                    $remainingCoins = getTotalCoins(20);
                    if ($remainingCoins < 40) {
                        $remainingCoins = 'Not enough coins';
                    }
                    // Generate HTML output



                    $htmlOutput .= '<table>';



                    foreach ($data as $item) {



                        // $htmlOutput .= '<tr>';



                        // $htmlOutput .= '<ul>';



                        $htmlOutput .= "<tr><th><strong>Entities</strong></th><th>Description</th></tr>";



                        foreach ($item as $key => $value) {



                            $htmlOutput .= "<tr><td><strong>$key:</strong></td><td> $value</td></tr>";
                        }



                        // $htmlOutput .= '</ul>';



                        // $htmlOutput .= '</li>';

                    }



                    $htmlOutput .= '</table>';
                } else {


                    $output = "No data found.";
                }
            } else {



                $output = "Error: Unable to fetch data from API.";
            }
        } else {



            // Invalid input message



            $output = "Please enter an 8-digit Jazz Cash ID.";
        }
    } else {



        // Empty input message



        $output = "Please enter a Jazz Cash ID.";
    }
}



?>







<!DOCTYPE html>



<html>

<div class="row mt-3 d-flex justify-content-center">

    <div class="col-md-6" style="text-align:center;">

        <?php

        if ((isset($output)) && (strlen($output) > 0)) {

            // echo'<button class="btn btn-success" id="downloadImage">Download as PNG</button>';

        }

        ?>

    </div>

</div>



<!-- <div class="row mt-3 d-flex justify-content-center" id="printdiv" style="

    display: flex !important;

    justify-content: flex-start !important;

    align-items: center !important;">

    <div class="col-md-6">

      

            <?php

            // if( (isset($output)) && (strlen($output) > 0) ) { 
            //     echo $output;
            //     unset($output);
            //     unset($_POST);
            // }

            ?>

        

      </table>

      </div>

  </div> -->



</div>









<!-- my js -->

<script>
    var colMd6 = document.querySelector('.col-md-6');
    colMd6.style.margin = 'auto';
    colMd6.style.float = 'none'; // Remove any float that might affect centering
</script>

<style>
    body {
        margin: 0;
        font-family: Arial
    }



    .topnav {

        overflow: hidden;

        background-color: #333;

    }



    .topnav a {

        float: left;

        display: block;

        color: #f2f2f2;

        text-align: center;

        padding: 14px 16px;

        text-decoration: none;

        font-size: 25px;

    }



    .active {

        background-color: #04AA6D;

        color: white;

    }



    .topnav .icon {

        display: none;

    }



    .dropdown {

        float: left;

        overflow: hidden;

    }



    .dropdown .dropbtn {

        font-size: 17px;

        border: none;

        outline: none;

        color: white;

        padding: 14px 16px;

        background-color: inherit;

        font-family: inherit;

        margin: 0;

    }



    .dropdown-content {

        display: none;

        position: absolute;

        background-color: #f9f9f9;

        min-width: 160px;

        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);

        z-index: 1;

    }



    .dropdown-content a {

        float: none;

        color: black;

        padding: 12px 16px;

        text-decoration: none;

        display: block;

        text-align: left;

    }



    .topnav a:hover,
    .dropdown:hover .dropbtn {

        background-color: green;

        color: white;

    }



    .dropdown-content a:hover {

        background-color: #ddd;

        color: black;

    }



    .dropdown:hover .dropdown-content {

        display: block;

    }



    @media screen and (max-width: 600px) {

        .topnav a:not(:first-child),
        .dropdown .dropbtn {

            display: none;

        }

        .topnav a.icon {

            float: right;

            display: block;

        }

    }



    @media screen and (max-width: 600px) {

        .topnav.responsive {
            position: relative;
        }

        .topnav.responsive .icon {

            position: absolute;

            right: 0;

            top: 0;

        }

        .topnav.responsive a {

            float: none;

            display: block;

            text-align: left;

        }

        .topnav.responsive .dropdown {
            float: none;
        }

        .topnav.responsive .dropdown-content {
            position: relative;
        }

        .topnav.responsive .dropdown .dropbtn {

            display: block;

            width: 100%;

            text-align: left;

        }

    }
</style>

<head>

    <div class="topnav" id="myTopnav">

        <a href="index.php" class="active">Home</a>

        <a href="index.php">Jazz+Warid Data</a>

        <a href="ufone.php">Ufone+zong+Telenor Fresh</a>

        <a href="jazzcash.php?n">Jazz Cash Search By Number </a>

        <a href="jazzcash.php?c">Jazz Cash Search By CNIC </a>

        <a href="#">Marchant Till Id Data</a>

        <div class="dropdown">



        </div>

        <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>

    </div>

    <title>Jazz Cash Till Id Details 2024</title>

</head>







<body>



    <!-- Your HTML content here -->



    <h1>Jazz Cash Till Id Details 2024</h1>







    <!-- Search form -->



    <div class="container">

        <form method="POST" action="" class="mt-3">

            <div class="mb-3" align="center">

                <label for="search_query" class="form-label">Search Jazz Cash ID:</label>

                <input type="text" id="search_query" name="search_query" class="form-control" style="width: 50%;" required>

            </div>

            <div class="mb-3">

                <input type="submit" name="search" value="Search" class="btn btn-success btn-sm">

            </div>

            



            <div class="card text-white bg-info mb-3" style="max-width: 18rem; margin: 0 auto;">
    <div class="card-header text-center"><button onclick="document.location='index.php'" class="btn btn-warning btn-sm"><i class="fas fa-arrow-left"></i> Dashboard</button></div>
    <div class="card-body text-center" style="font-size: 22px;">
        <label>Coins Purchase Date <br> <span class="badge badge-warning"><?= $CoinsExpiry ?> </span></label>
        <br>
        <label>Coins Expiry Date <br> <span class="badge badge-warning" id="countdown"> </span></label>
    </div>
</div>





        </form>

    </div>









    <!-- Display search results -->



    <?php if (!empty($output)) {
        deleteMyCoins(20);

    ?>
        <div class="output">
            <?php echo $output;
            unset($output);
            unset($_POST); ?>
        </div>
    <?php } ?>


    <!-- Display HTML formatted output -->



    <?php
    if ($DeductMyCoins != false) {

    ?>
        <p>Remaining Coins: <?php echo "<b class='text-success'>" . $remainingCoins . "</b>"; ?> <i class="fas fa-coins" style="color: gold;"></i>
        <?php

    } else {

        ?>
        <p>Remaining Coins: <?php echo "<b class='text-success'>" . $DeductMyCoinsMessage . "</b>"; ?> <i class="fas fa-coins" style="color: gold;"></i>
        <?php
        exit;
    }
        ?>




        </p>

        <?php if (!empty($htmlOutput)) : ?>

            <button class="btn btn-success" id="download-btn">Download as PNG</button><br>

            <div class="output">

                <?php echo $htmlOutput; ?>

            </div>

        <?php endif; ?>





</body>




<script>



var expiryDate = new Date("<?php echo $updatedExpiry; ?>").getTime();
    
    if('<?php echo $updatedExpiry; ?>' == '' || '<?php echo $updatedExpiry; ?>' == undefined ){
        
        $("#countdown").html('<a href="https://wa.me/+9203207483733" style="text-decoration:none;color:white;cursor:pointer" target="_blank">Buy Now</a>');
    }
    else{
    var x = setInterval(function() {
        var now = new Date().getTime();
        var distance = expiryDate - now;
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        $("#countdown").text(days + "d " + hours + "h " + minutes + "m " + seconds + "s ");

        if (distance < 0) {
            clearInterval(x);
            $("#countdown").text("Expired");
        }
    }, 1000);
    }




    function getCurrentDateTime() {
        var now = new Date();
        var day = ("0" + now.getDate()).slice(-2);
        var month = ("0" + (now.getMonth() + 1)).slice(-2);
        var year = now.getFullYear();
        var hours = ("0" + now.getHours()).slice(-2);
        var minutes = ("0" + now.getMinutes()).slice(-2);

        return year + "-" + month + "-" + day + "_" + hours + ":" + minutes;
    }



    document.getElementById('download-btn').addEventListener('click', function() {
        html2canvas(document.querySelector('.output')).then(function(canvas) {
            var link = document.createElement('a');
            link.download = 'simdb-' + getCurrentDateTime() + '.png'
            link.href = canvas.toDataURL();
            link.click();
        });
    });
</script>



<script>
    // Function to download the content of a div as a PNG image
    function downloadDivAsPng(divId, fileName) {
        const element = document.getElementById(divId);

        html2canvas(element).then(function(canvas) {
            const imgData = canvas.toDataURL('image/png');
            const link = document.createElement('a');
            link.download = fileName;
            link.href = imgData;
            link.click();
        });
    }

    // Event listener for the download button
    document.getElementById('downloadImage').addEventListener('click', function() {
        downloadDivAsPng('output', 'output.png');
    });
</script>


</script>

</html>