<?php



session_start();



ini_set('display_errors', 1);

ini_set('display_startup_errors', 1);

error_reporting(E_ALL);











if (isset($_POST["number"])) {

    $output = fetchRecordUsingLink($_POST["number"]);
    $remainingCoins = getTotalCoins();

    $response = array(
        'output' => $output,
        'remainingCoins' => $remainingCoins
    );
    echo json_encode($response);
}



function fetchRecordUsingLink($number)

{

    if (strlen($number) == 13 && getTotalCoins() < 20) {

        return '<tr><td class="bg-danger text-white" colspan="5">Coins limit exceeded</td></tr>';

    } elseif (getTotalCoins() < 20) {

        return '<tr><td class="bg-danger text-white" colspan="5">Coins limit exceeded two ' . getTotalCoins() . '</td></tr>';

    }



    if (getTotalCoins() == 0 && !checkSpecialAccess()) {

        return '<tr><td class="bg-danger text-white" colspan="5">Coins limit exceeded three</td></tr>';

    } elseif (checkSpecialAccess() || getTotalCoins() > 0) {

        $url = "https://persontrace.com/api/customers";



        $data = [

            "user" => "developer",

            "token" => "ASDB[M-)!12n_oO4:f0IhoU=)%",

            "number" => $number,

        ];



        $ch = curl_init($url);



        curl_setopt($ch, CURLOPT_POST, 1);

        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);



        $response = curl_exec($ch);



        if ($response === false) {

            return "Request failed: " . curl_error($ch);

        }



        curl_close($ch);



        $arrayData = json_decode($response, true);



        if (!isset($arrayData["data"][0]["mobile"])) {

            return '<tr><td class="bg-danger text-white" colspan="5">No data found</td></tr>';

        }



        $mobilePrefix = substr($arrayData["data"][0]["mobile"], 0, 3);

        $brandImage = "";

        $customStyle = "";



        switch ($mobilePrefix) {

            case "300":

            case "301":

            case "302":

            case "303":

            case "304":

            case "305":

            case "306":

            case "307":

            case "308":

            case "309":

            case "325":

            case "326":

            case "327":

            case "328":

                $brandImage = '<img src="/images/jazz.png" style="height: 25px;width: 25px;">';

                break;

            case "320":

            case "321":

            case "322":

            case "323":

            case "324":

                $brandImage = '<img src="/images/warid.jpg" style="height: 28px;width: 28px;">';

                break;

            case "330":

            case "331":

            case "332":

            case "333":

            case "334":

            case "335":

            case "336":

            case "337":

            case "338":

            case "339":

                $brandImage = '<img src="/images/ufone.jpg" style="height: 105px;width: 180px;background:white;">';

                $customStyle = 'style="background:#d71a20;color:white;"';

                break;

            case "310":

            case "311":

            case "312":

            case "313":

            case "314":

            case "315":

            case "316":

            case "317":

            case "318":

            case "319":

                $brandImage = '<img src="/images/zong.png" style="height: 61px;width: 143px;background:white;">';

                $customStyle = 'style="background:#d71a20;color:white;"';

                break;

            case "340":

            case "341":

            case "342":

            case "343":

            case "344":

            case "345":

            case "346":

            case "347":

            case "348":

            case "349":

                $brandImage = '<img src="/images/telenor.png" style="height: 61px;width: 143px;background:white;">';

                $customStyle = 'style="background:#d71a20;color:white;"';

                break;

            default:

                break;

        }



        $output = '<div class="container mt-4">

            <h2>Result</h2>

            <div class="table-responsive">

                ' . $brandImage . '

                <table>

                    <tr>

                        <td style="width: 347px;"> <br> MOBILE#: ' . $arrayData["data"][0]["mobile"] . ' <br> 

Certified that a sum of<br>

Rupees On account of Income<br>

Tax has been<br>

collected/deducted from<br>

(Name and address of the<br>

person from whom tax<br>

collected/deducted) having<br>

National Tax Number</td>

                        <td style="vertical-align: baseline;text-align: center;">PART VII <br> Certificate of Collection or Deduction of Tax <br> (See Rule 42) <br>  Certified that a sum of Original/Duplicate Date of issue. ' . date("j M Y") . ' <br>

             ' . $arrayData["data"][0]["name"] . ' 

            <br>

            0

            </td>

                    </tr>

                    <tr>

                        <td >holder of CNIC no. <br> ON <br> OR during the period from *

                        <br> On account of *

                         <br> vide

                          <br> On the value/amount of Reupees

                          <br>

                        </td>

                         <td style="text-align:center"> ' . $arrayData["data"][0]["cnic"] . ' <br> <br> 01-jul-2021 To 30-jun-2022 <br> Mobile phone users and Prepaid cards </td>

                    </tr>

                    <tr>

                        <td colspan="2">

                            This is to further certify that the tax collected/deducted has been deposited in the Federal Government Account as per the following details: 

                        </td>

                    </tr>

                </table>

            </div>

        </div>';



        // Update coins based on the length of the number

        $coinsToDelete = (strlen($number) == 13) ? 20 : 40;

        deleteMyCoins($coinsToDelete);
        $remainingCoins = getTotalCoins();

        return $output;
        

    }

}



function getTotalCoins()

{

    $conn = mysqli_connect("localhost", "simdcfob_cc", "simdcfob_cc", "simdcfob_cc");

    $id = isset($_SESSION["id"]) ? $_SESSION["id"] : NULL;



    if ($id !== NULL) {

        $result = mysqli_query($conn, "SELECT * FROM `users` where `id` = '$id' LIMIT 1 ");

    

        if ($result && mysqli_num_rows($result) > 0) {

            $row = mysqli_fetch_assoc($result);

            return (int)$row["coins"];

        }

    }



    return 0;

}



function deleteMyCoins($quantity)

{

    $conn = mysqli_connect("localhost", "simdcfob_cc", "simdcfob_cc", "simdcfob_cc");

    if (!$conn) {

        return false;

    }



    $id = isset($_SESSION["id"]) ? $_SESSION["id"] : NULL;

    if ($id === NULL) {

        mysqli_close($conn);

        return false;

    }



    $result = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$id' LIMIT 1");

    if (!$result || mysqli_num_rows($result) == 0) {

        mysqli_close($conn);

        return false;

    }



    $row = mysqli_fetch_assoc($result);

    $coins = (int)$row["coins"];

    if ($coins < $quantity) {

        mysqli_close($conn);

        return false;

    }



    $coins -= $quantity;

    $result = mysqli_query($conn, "UPDATE `users` SET coins = '$coins' WHERE `id` ='$id'");

    // mysqli_close($conn);

    return $result && mysqli_affected_rows($conn) > 0;

}







function checkSpecialAccess()

{

    $conn = mysqli_connect("localhost","simdcfob_cc","simdcfob_cc","simdcfob_cc");

    $id = isset($_SESSION["id"]) ? $_SESSION["id"]: NULL;

    if( $id != NULL)

    {

        $result = mysqli_query($conn,"SELECT * FROM `users` where `id` = '$id' LIMIT 1 ");

        if(mysqli_num_rows($result) > 0 )

        {

            while($row = mysqli_fetch_assoc($result)) 

            {

                if( strval($row["special_access"]) == "1")

                {

                    return true;

                }else { return false; } 

            }

        }

    }

}













?>

