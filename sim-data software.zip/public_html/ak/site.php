<?php

// Replace with your bot token and webhook URL
$botToken = '7260752375:AAF6qbERiUGs5apA6hoQnh4QI27zza9yWA0';
$webhookUrl = 'https://simdb.live/ak/site.php'; // Replace with your actual webhook URL

// Set webhook
$apiUrl = 'https://api.telegram.org/bot' . $botToken . '/';
$response = file_get_contents($apiUrl . 'setWebhook?url=' . $webhookUrl);
echo $response;

// Handle incoming messages
$update = json_decode(file_get_contents('php://input'), true);

// Log the update for debugging
file_put_contents('php://stderr', print_r($update, true));

if (isset($update['message'])) {
    $chatId = $update['message']['chat']['id'];
    $messageText = $update['message']['text'];

    switch ($messageText) {
        case '/start':
            sendMessage($chatId, "Welcome to Number Data Bot! Please enter a number.");
            break;

        case '/help':
            sendMessage($chatId, "This bot fetches data based on the number you provide.");
            break;

        default:
            if (is_numeric($messageText)) {
                // Call the API with the provided number
                $apiUrl = "https://kingfinders.click/api/Asim.php?number=" . urlencode($messageText);
                $apiResponse = file_get_contents($apiUrl);

                if ($apiResponse !== FALSE && !empty($apiResponse)) {
                    // Send the fetched data to the user
                    sendMessage($chatId, formatApiResponse($apiResponse));
                } else {
                    sendMessage($chatId, "Data for this number is not available.");
                }
            } else {
                sendMessage($chatId, "Please enter a valid number. Use /start or /help.");
            }
            break;
    }
}

// Function to send messages
function sendMessage($chatId, $message)
{
    global $botToken;
    $apiUrl = 'https://api.telegram.org/bot' . $botToken . '/';
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];

    $response = file_get_contents($apiUrl . 'sendMessage?' . http_build_query($data));
    file_put_contents('php://stderr', print_r($response, true)); // Log the response for debugging
}

// Function to format the API response for Telegram message
function formatApiResponse($apiResponse)
{
    // Customize this function based on your API response structure
    return "Data: " . htmlspecialchars($apiResponse);
}