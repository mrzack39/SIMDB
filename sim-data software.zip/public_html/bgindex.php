<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Background Remover</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f0f0f0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Ensures the body takes up the full height of the viewport */
        }
        h1 {
            margin-bottom: 20px;
            color: #333;
        }
        #fileInput {
            margin-bottom: 20px; /* Add some space below the file input */
        }
        #outputImage {
            max-width: 100%;
            margin-top: 20px;
            background-color: white;
            padding: 10px;
            border-radius: 20px;
        }
        #downloadButton {
            margin-top: 20px;
            display: none; /* initially hidden */
            background-color: green; /* Set button background color to green */
            color: white; /* Set text color to white */
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .loading {
            border: 16px solid #f3f3f3;
            border-top: 16px solid #3498db;
            border-radius: 50%;
            width: 120px;
            height: 120px;
            animation: spin 5s linear infinite; /* Changed from 2s to 5s */
            margin: 20px auto;
        }

        #removeBackgroundButton {
            background-color: green;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        #removeBackgroundButton:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
<button onclick="document.location='index.php'" style="background-color: blue; color: white; border: none; padding: 10px 20px; font-size: 16px; border-radius: 5px; cursor: pointer;">Dashbord</button>
<button onclick="document.location='bgindex.php'" style="background-color: green; color: white; border: none; padding: 10px 20px; font-size: 16px; border-radius: 5px; cursor: pointer;">Remove New Image</button>
    <h1>Background Remover</h1>
    
    <input type="file" accept="image/*" id="fileInput">
    <button id="removeBackgroundButton" onclick="removeBackground()">Remove Background</button>
    <br>
    
    <br>
    <div class="loading" id="loadingIndicator" style="display: none;"></div>
    <br>
    <a id="downloadLink" download="processed_image.png" href="#" style="display: none;">
        <button id="downloadButton">Download HD Image</button>
    </a>
 
 

    <script>
        const apiKey = 'f816sPZPLXXnBTQxzVpuS6na';
        const apiUrl = 'https://api.remove.bg/v1.0/removebg';

        async function removeBackground() {
            const fileInput = document.getElementById('fileInput');
            const outputImage = document.getElementById('outputImage');
            const downloadButton = document.getElementById('downloadButton');
            const loadingIndicator = document.getElementById('loadingIndicator');
            const downloadLink = document.getElementById('downloadLink');

            if (!fileInput.files || !fileInput.files[0]) {
                alert('Please select an image.');
                return;
            }

            const formData = new FormData();
            formData.append('image_file', fileInput.files[0]);
            formData.append('size', 'auto');

            try {
                loadingIndicator.style.display = 'block';

                const response = await fetch(apiUrl, {
                    method: 'POST',
                    headers: {
                        'X-Api-Key': apiKey
                    },
                    body: formData
                });

                loadingIndicator.style.display = 'none';

                if (!response.ok) {
                    const error = await response.text();
                    throw new Error(`Error: ${error}`);
                }

                const result = await response.blob();
                outputImage.src = URL.createObjectURL(result);

                // Show download button
                downloadLink.style.display = 'block';
                downloadButton.style.display = 'inline-block'; // Display download button
            } catch (error) {
                loadingIndicator.style.display = 'none';
                alert(error.message);
            }
        }

        // Function to set download link URL
        function setDownloadURL() {
            const outputImage = document.getElementById('outputImage');
            const downloadLink = document.getElementById('downloadLink');
            downloadLink.href = outputImage.src;
        }

        // Call setDownloadURL() when image loads
        document.getElementById('outputImage').onload = setDownloadURL;
    </script>
    
</body>
</html>
