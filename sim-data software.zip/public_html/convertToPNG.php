<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Generate a unique filename for the PNG image
    $fileName = 'table_' . uniqid() . '.png';

    // Path to save the image (adjust this based on your server setup)
    $imagePath = 'user-images/' . $fileName;

    // Use wkhtmltoimage to convert HTML to PNG
    exec("wkhtmltoimage --quality 100 --width 800 'https://simdb.live/index1.php' '$imagePath'");

    // Respond with the image filename
    echo json_encode(['imageFileName' => $fileName]);
} else {
    // Handle invalid requests
    http_response_code(400);
    echo "Invalid request method";
}

?>
