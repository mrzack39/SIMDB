
<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    
    <title>Sim Data </title>
    <link rel="stylesheet" href="https://capp.nicepage.com/3d51038990ebdca254c7d5abc225df31297e9144/nicepage.css" media="screen">
    <link rel="stylesheet" href="https://website2137743.nicepage.io/nicepage-site.css" media="screen">
    <link rel="stylesheet" href="https://website2137743.nicepage.io/Page-8.css" media="screen">
    <script class="u-script" type="text/javascript" src="https://capp.nicepage.com/assets/jquery-3.5.1.min.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="https://capp.nicepage.com/3d51038990ebdca254c7d5abc225df31297e9144/nicepage.js" defer=""></script>
     
     
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

   <style>
    .u-section-1 {
        background-image: none !important;
        background-position: 50% 28.71%;
    }
   </style>
   
  </head>
  <body data-path-to-root="/" data-include-products="false" class="u-body u-xl-mode" data-lang="en">
       <?php include('header.php'); ?>
 
    <section class="u-align-center u-clearfix u-image u-section-1" id="carousel_b6d2" data-image-width="720" data-image-height="1080">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-custom-font u-font-montserrat u-text u-text-body-alt-color u-text-1"> Simple prices, flexible options &amp; nothing hidden</h2>
        <div class="u-expanded-width u-list u-list-1">
          <div class="u-repeater u-repeater-1">
            <div class="u-black u-container-style u-list-item u-opacity u-opacity-60 u-repeater-item u-shape-rectangle u-list-item-1">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-1">
                <div class="u-align-center u-container-style u-expanded-width u-group u-palette-3-base u-group-1">
                  <div class="u-container-layout u-valign-middle u-container-layout-2">
                    <h3 class="u-custom-font u-font-montserrat u-text u-text-body-alt-color u-text-2">Free</h3>
                  </div>
                </div>
                <h4 class="u-custom-font u-font-montserrat u-text u-text-default u-text-palette-3-base u-text-3">$0</h4>
                <ul class="u-align-left u-custom-list u-text u-text-4">
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>15 Users
                  </li>
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>Feature 2 
                  </li>
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>Feature 3 
                  </li>
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>Feature 4
                  </li>
                </ul>
                
                <a href="https://wa.me/+923207483733?text=I'm%20interested%20in%20your%20First%20Plan" target="_blank" class="u-active-palette-3-light-3 u-btn u-button-style u-custom-item u-hover-palette-3-light-3 u-palette-3-base u-text-body-alt-color u-text-hover-black u-btn-1" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">get plan</a>
              </div>
            </div>
            <div class="u-black u-container-style u-list-item u-opacity u-opacity-60 u-repeater-item u-shape-rectangle u-list-item-2">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-3">
                <div class="u-align-center u-container-style u-expanded-width u-group u-palette-3-base u-group-2">
                  <div class="u-container-layout u-valign-middle u-container-layout-4">
                    <h3 class="u-custom-font u-font-montserrat u-text u-text-body-alt-color u-text-default u-text-5">Individual</h3>
                  </div>
                </div>
                <h4 class="u-custom-font u-font-montserrat u-text u-text-default u-text-palette-3-base u-text-6">$29</h4>
                <ul class="u-align-left u-custom-list u-text u-text-7">
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>15 Users
                  </li>
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>Feature 2 
                  </li>
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>Feature 3 
                  </li>
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>Feature 4
                  </li>
                </ul>
                <a href="https://wa.me/+923207483733?text=I'm%20interested%20in%20your%20Second%20Plan" class="u-active-palette-3-light-3 u-border-none u-btn u-button-style u-custom-item u-hover-palette-3-light-3 u-palette-3-base u-text-body-alt-color u-text-hover-black u-btn-2" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">get plan</a>
              </div>
            </div>
            <div class="u-black u-container-style u-list-item u-opacity u-opacity-60 u-repeater-item u-shape-rectangle u-list-item-3">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-5">
                <div class="u-align-center u-container-style u-expanded-width u-group u-palette-3-base u-group-3">
                  <div class="u-container-layout u-valign-middle u-container-layout-6">
                    <h3 class="u-custom-font u-font-montserrat u-text u-text-body-alt-color u-text-default u-text-8">Business</h3>
                  </div>
                </div>
                <h4 class="u-custom-font u-font-montserrat u-text u-text-default u-text-palette-3-base u-text-9">$59</h4>
                <ul class="u-align-left u-custom-list u-text u-text-10">
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>15 Users
                  </li>
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>Feature 2 
                  </li>
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>Feature 3 
                  </li>
                  <li>
                    <div class="u-list-icon u-text-palette-3-base">
                      <div xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content">■</div>
                    </div>Feature 4
                  </li>
                </ul>
                <a href="https://wa.me/+923207483733?text=I'm%20interested%20in%20your%20Third%20Plan" class="u-active-palette-3-light-3 u-btn u-button-style u-custom-item u-hover-palette-3-light-3 u-palette-3-base u-text-body-alt-color u-text-hover-black u-btn-3" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">get plan</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    
    
     
  
</body></html>